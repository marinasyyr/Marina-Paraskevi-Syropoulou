import sqlite3

# Connect to the database
conn = sqlite3.connect('instance/users.db')
cursor = conn.cursor()

# Query to select all users
cursor.execute("SELECT username, role FROM user;")
users = cursor.fetchall()

# Print the users
for user in users:
    print(f'Username: {user[0]}, Role: {user[1]}')

# Close the connection
conn.close()
