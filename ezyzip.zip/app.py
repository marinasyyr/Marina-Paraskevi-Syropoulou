from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, SelectField
from wtforms.validators import DataRequired, Length
from flasgger import Swagger
from forms import SongForm, ProfileForm 

app = Flask(__name__)
app.config['SECRET_KEY'] = 'mysecretkey'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
db = SQLAlchemy(app)
migrate = Migrate(app, db)

# Ενεργοποίηση του Swagger
swagger = Swagger(app)

# Δημιουργία αντικειμένων LoginManager και FlaskLogin
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# === Models (Μοντέλα) ===
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)
    role = db.Column(db.String(10), nullable=False, default='user')
    is_active = db.Column(db.Boolean, default=True)
    emotion = db.Column(db.String(50), default="Happy")
    
    
    songs = db.relationship('Song', backref='user', lazy=True)


    def get_id(self):
        return str(self.id)

    def is_admin(self):
        return self.role == 'admin'
    
class Song(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    artist = db.Column(db.String(100), nullable=False)
    emotion = db.Column(db.String(50), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)


    def __repr__(self):
        return f"<Song {self.title} by {self.artist}>"

# === Forms (Φόρμες) ===
class RegisterForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=2, max=150)])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=6)])
    role = SelectField('Role', choices=[('user', 'User'), ('admin', 'Admin')], validators=[DataRequired()])
    submit = SubmitField('Register')
    
class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')
    
class SongForm(FlaskForm):
    title = StringField('Song Title', validators=[DataRequired()])
    artist = StringField('Artist', validators=[DataRequired()])
    emotion = SelectField('Emotion', choices=[
        ('Happy', 'Happy'),
        ('Sad', 'Sad'),
        ('Angry', 'Angry'),
        ('Nostalgic', 'Nostalgic'),
        ('Fearful', 'Fearful'),
        ('In Love', 'In Love'),
        ('Grateful', 'Grateful'),
        ('Surprised', 'Surprised'),
        ('Relaxed', 'Relaxed'),
        ('Anxious', 'Anxious'),
        ('Inspired', 'Inspired'),
        ('Calm', 'Calm')
    ], validators=[DataRequired()])

class ProfileForm(FlaskForm):
    emotion = SelectField('Select Emotion', choices=[ 
        ('Happy'),
        ('Sad'),
        ('Angry'),
        ('Nostalgic'),
        ('Fearful'),
        ('In Love'),
        ('Grateful'),
        ('Surprised'),
        ('Relaxed'),
        ('Anxious'),
        ('Inspired'),
        ('Calm')
    ], default='Happy')
    submit = SubmitField('Update Emotion')

# === Routes (Διαδρομές) ===

@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        hashed_password = generate_password_hash(form.password.data)
        # Δημιουργία νέου χρήστη με τον επιλεγμένο ρόλο
        new_user = User(username=form.username.data, password=hashed_password, role=form.role.data)
        db.session.add(new_user)
        db.session.commit()
        flash('Your account has been created!', 'success')
        return redirect(url_for('login'))
    return render_template('register.html', form=form)

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and check_password_hash(user.password, form.password.data):
            login_user(user)
            flash('Login successful!', 'success')
            return redirect(url_for('profile'))
        else:
            flash('Login failed. Check your username and/or password.', 'danger')
    return render_template('login.html', form=form)

from flask_login import current_user

@app.route('/add_song', methods=['GET', 'POST'])
def add_song():
    if request.method == 'POST':
        title = request.form['title']
        artist = request.form['artist']
        emotion = request.form['emotion']
        new_song = Song(title=title, artist=artist, emotion=emotion, user_id=current_user.id)
        db.session.add(new_song)
        db.session.commit()
        flash("Song added successfully!")
        return redirect(url_for('add_song'))

    songs = Song.query.all()
    print("All songs:", songs)
    return render_template('add_song.html', songs=songs)


@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    form = ProfileForm()
    if form.validate_on_submit():
        current_user.emotion = form.emotion.data
        db.session.commit()
        flash('Your emotion has been updated!', 'success')

    emotion_classes = {
        'Happy': 'happy',
        'Sad': 'sad',
        'Angry': 'angry',
        'Nostalgic': 'nostalgic',
        'Fearful': 'fearful',
        'In Love': 'in-love',
        'Grateful': 'grateful',
        'Surprised': 'surprised',
        'Relaxed': 'relaxed',
        'Anxious': 'anxious',
        'Inspired': 'inspired',
        'Calm': 'calm',
    }
    emotion_class = emotion_classes.get(current_user.emotion, 'happy')

    songs = Song.query.all()
    print(f"All songs: {[song.title for song in songs]}")

    if not songs:
        songs_dict = {
            'Happy': ['Happy - Pharrell Williams', 'Walking on Sunshine - Katrina and the Waves', 'Good as Hell - Lizzo'],
            'Sad': ['Someone Like You - Adele', 'Fix You - Coldplay', 'The Night We Met - Lord Huron'],
            'Angry': ['Break Stuff - Limp Bizkit', 'Take the Power Back - Rage Against The Machine', 'Killing In The Name - Rage Against The Machine'],
            'Nostalgic': ['Summer of 69 - Bryan Adams', 'The Way We Were - Barbra Streisand', 'Yesterday - The Beatles'],
            'Fearful': ['Disturbia - Rihanna', 'Thriller - Michael Jackson', 'The Sound of Silence - Simon & Garfunkel'],
            'In Love': ['All of Me - John Legend', 'I Will Always Love You - Whitney Houston', 'Perfect - Ed Sheeran'],
            'Grateful': ['Thank You - Dido', 'Isnt She Lovely - Stevie Wonder', 'Count On Me - Bruno Mars'],
            'Surprised': ['Unfinished Sympathy - Massive Attack', 'Bohemian Rhapsody - Queen', 'Rolling in the Deep - Adele'],
            'Relaxed': ['Weightless - Marconi Union', 'Sunset Lover - Petit Biscuit', 'Banana Pancakes - Jack Johnson'],
            'Anxious': ['Breathe Me - Sia', 'The A Team - Ed Sheeran', 'Mad World - Gary Jules'],
            'Inspired': ['Eye of the Tiger - Survivor', 'Lose Yourself - Eminem', 'Stronger - Kanye West'],
            'Calm': ['Clair de Lune - Claude Debussy', 'Spiegel im Spiegel - Arvo Pärt', 'Watermark - Enya'],
        }
        selected_songs = songs_dict.get(current_user.emotion, [])
    else:
        selected_songs = [f'{song.title} - {song.artist}' for song in songs]

    return render_template('profile.html', form=form, songs=selected_songs, emotion_class=emotion_class)


# Διαδρομή αποσύνδεσης (logout)
@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

# Διαδρομή φόρτωσης χρήστη κατά τη διάρκεια του login
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Εξαρχής εκκίνηση της εφαρμογής
if __name__ == "__main__":
    with app.app_context():
        db.drop_all()
        db.create_all()  # Δημιουργεί τις βάσεις δεδομένων αν δεν υπάρχουν ήδη
        print("Database recreated successfully!")
    app.run(debug=True)