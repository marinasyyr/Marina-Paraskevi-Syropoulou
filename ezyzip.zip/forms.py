from flask_wtf import FlaskForm
from wtforms import StringField, SelectField, SubmitField
from wtforms.validators import DataRequired

class SongForm(FlaskForm):
    title = StringField('Title', validators=[DataRequired()])
    artist = StringField('Artist', validators=[DataRequired()])
    emotion = SelectField(
        'Emotion',
        choices=[
            ('Happy', 'Happy'),
            ('Sad', 'Sad'),
            ('Angry', 'Angry'),
            ('Nostalgic', 'Nostalgic'),
            ('Fearful', 'Fearful'),
            ('In Love', 'In Love'),
            ('Grateful', 'Grateful'),
            ('Surprised', 'Surprised'),
            ('Relaxed', 'Relaxed'),
            ('Anxious', 'Anxious'),
            ('Inspired', 'Inspired'),
            ('Calm', 'Calm')
        ],
        validators=[DataRequired()]
    )
    submit = SubmitField('Add Song')


class ProfileForm(FlaskForm):
    emotion = SelectField(
        'Emotion',
        choices=[
            ('Happy', 'Happy'),
            ('Sad', 'Sad'),
            ('Angry', 'Angry'),
            ('Nostalgic', 'Nostalgic'),
            ('Fearful', 'Fearful'),
            ('In Love', 'In Love'),
            ('Grateful', 'Grateful'),
            ('Surprised', 'Surprised'),
            ('Relaxed', 'Relaxed'),
            ('Anxious', 'Anxious'),
            ('Inspired', 'Inspired'),
            ('Calm', 'Calm')
        ],
        validators=[DataRequired()]
    )
    submit = SubmitField('Update Emotion')
